<?php
require_once __DIR__ . '/../includes/config.php';

/* ================================
   Count Products
================================ */
function GetNumberOfProducts() {
    $conn = new mysqli(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("DB error");
    }

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM products");
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $conn->close();

    return $result['total'] ?? 0;
}

/* ================================
   List Products with Filters
================================ */
function ListAllProducts(
    $start = 0,
    $limit = 50,
    $name = '',
    $category_id = '',
    $min_price = '',
    $max_price = '',
    $has_discount = false
) {
    $conn = new mysqli(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("Database connection failed");
    }

    $sql = "
        SELECT 
            p.product_id,
            p.image,
            p.name AS ProductName,
            p.price AS original_price,
            c.name AS CategoryName,

            d.discount_id,
            d.discount_percent,
            d.start_date,
            d.end_date,
            d.is_active,

            IF(
                d.discount_id IS NOT NULL
                AND d.is_active = 1
                AND CURDATE() BETWEEN d.start_date AND d.end_date,
                p.price - (p.price * d.discount_percent / 100),
                p.price
            ) AS current_price

        FROM products p
        LEFT JOIN categories c ON p.category_id = c.category_id
        LEFT JOIN discounts d ON p.product_id = d.product_id
        WHERE 1=1
    ";

    $params = [];
    $types  = "";

    if ($name !== '') {
        $sql .= " AND p.name LIKE ?";
        $params[] = "%$name%";
        $types .= "s";
    }

    if ($category_id !== '') {
        $sql .= " AND p.category_id = ?";
        $params[] = $category_id;
        $types .= "i";
    }

    if ($min_price !== '') {
        $sql .= " AND p.price >= ?";
        $params[] = $min_price;
        $types .= "d";
    }

    if ($max_price !== '') {
        $sql .= " AND p.price <= ?";
        $params[] = $max_price;
        $types .= "d";
    }

    /* 🔥 Discount Filter */
    if ($has_discount) {
        $sql .= "
            AND d.discount_id IS NOT NULL
            AND d.is_active = 1
            AND CURDATE() BETWEEN d.start_date AND d.end_date
        ";
    }

    $sql .= " ORDER BY p.product_id DESC LIMIT ?, ?";
    $params[] = $start;
    $params[] = $limit;
    $types .= "ii";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();

    $result = $stmt->get_result();
    $products = [];

    while ($row = $result->fetch_assoc()) {
        $row['has_active_discount'] =
            $row['discount_id'] !== null &&
            $row['is_active'] == 1 &&
            date('Y-m-d') >= $row['start_date'] &&
            date('Y-m-d') <= $row['end_date'];

        $products[] = $row;
    }

    $stmt->close();
    $conn->close();

    return $products;
}
